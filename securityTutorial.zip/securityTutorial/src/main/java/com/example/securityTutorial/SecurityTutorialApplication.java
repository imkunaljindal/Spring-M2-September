package com.example.securityTutorial;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SecurityTutorialApplication {

	public static void main(String[] args) {
		SpringApplication.run(SecurityTutorialApplication.class, args);
	}

}
