package com.example.kalTak;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KalTakApplicationTests {

	@Test
	void contextLoads() {
	}

}
