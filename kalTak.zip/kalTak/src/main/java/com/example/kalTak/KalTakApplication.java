package com.example.kalTak;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KalTakApplication {

	public static void main(String[] args) {
		SpringApplication.run(KalTakApplication.class, args);
	}

}
